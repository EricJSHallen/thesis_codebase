# Plain Spectre v10

This version keeps the single-OCEAN-template / parallel-plain-Spectre architecture, but adds the missing PSF-to-text export step.

Install from the repository root:

```bash
mkdir -p processing/sim_run_code/plain_spectre_helpers_v10
cp plain_spectre_v10_bundle/setup_spectre_env.sh processing/sim_run_code/plain_spectre_helpers_v10/setup_spectre_env.sh
cp plain_spectre_v10_bundle/refresh_spectre_runtime.sh processing/sim_run_code/plain_spectre_helpers_v10/refresh_spectre_runtime.sh
cp plain_spectre_v10_bundle/run_spectre_worker.sh processing/sim_run_code/plain_spectre_helpers_v10/run_spectre_worker.sh
cp plain_spectre_v10_bundle/run_all_workers.sh processing/sim_run_code/plain_spectre_helpers_v10/run_all_workers.sh
cp plain_spectre_v10_bundle/run_export_case.sh processing/sim_run_code/plain_spectre_helpers_v10/run_export_case.sh
cp plain_spectre_v10_bundle/export_psf_to_txt.ocn processing/sim_run_code/plain_spectre_helpers_v10/export_psf_to_txt.ocn
cp plain_spectre_v10_bundle/spectre_sweep_plain_v10.sh processing/sim_run_code/spectre_sweep_plain_v10.sh
chmod +x processing/sim_run_code/spectre_sweep_plain_v10.sh processing/sim_run_code/plain_spectre_helpers_v10/*.sh
```

Run:

```bash
NUM_JOBS=4 RUN_LABEL=2channel_1syn_plain ./processing/sim_run_code/spectre_sweep_plain_v10.sh prep
cd thesis_database/<new_run_id>
./import_template.sh
./refresh_spectre_runtime.sh
source ./setup_spectre_env.sh && check_spectre_runtime
./run_all_workers.sh
./monitoring_commands.sh progress
```

`./run_template_ocean.sh` is optional if `/home/s5117909/simulation/synapsedualinputtb/spectre/schematic/netlist/input.scs` is already fresh.
