# Plain Spectre sweep v9

This replaces the previous `spectre_sweep_plain_v*.sh` workflow.

Main change: `run_spectre_worker.sh` now exports `output_signals.txt` from the Spectre PSF database immediately after each successful Spectre run. A case is marked `DONE` only after that export file exists and is non-empty.

## Install

From the repository root:

```bash
cp processing/sim_run_code/spectre_sweep_plain_v9.sh \
   processing/sim_run_code/spectre_sweep_plain_v9.sh.bak 2>/dev/null || true

cp /path/to/new/spectre_sweep_plain_v9.sh processing/sim_run_code/
chmod +x processing/sim_run_code/spectre_sweep_plain_v9.sh
```

If you extracted the bundle in the repository root, the file is already at:

```bash
processing/sim_run_code/spectre_sweep_plain_v9.sh
```

## Run

```bash
cd /home/s5117909/Documents/thesis/thesis_codebase
NUM_JOBS=4 RUN_LABEL=2channel_1syn_plain \
  ./processing/sim_run_code/spectre_sweep_plain_v9.sh prep
```

Then follow the printed next steps:

```bash
cd /home/s5117909/Documents/thesis/thesis_codebase/thesis_database/<new_run_dir>
./run_template_ocean.sh      # or load ciw_template_command.il in CIW
./import_template.sh
source ./setup_spectre_env.sh && check_spectre_runtime
./run_all_workers.sh
./monitoring_commands.sh progress
```

## Output location

For each case:

```text
<run_dir>/cases/st1_<f1>_hz__st2_<f2>_hz__trial_<n>/output_signals.txt
```

Check count:

```bash
find cases -name output_signals.txt | wc -l
./monitoring_commands.sh once
```
