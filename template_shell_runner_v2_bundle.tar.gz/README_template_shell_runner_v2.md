# Template shell runner v2

Use this as a replacement for `run_template_ocean.sh` inside a prepared plain-Spectre run directory.
It runs the template OCEAN script from the shell and avoids CIW.

Install in a run directory:

```bash
cp /path/to/run_template_ocean_shell_v2.sh ./run_template_ocean.sh
chmod +x ./run_template_ocean.sh
```

Run:

```bash
./run_template_ocean.sh
```

Then continue:

```bash
./import_template.sh
source ./setup_spectre_env.sh && check_spectre_runtime
./run_all_workers.sh
```

The log is written to:

```text
logs/template_ocean_shell.log
```
