#!/usr/bin/env bash
set -euo pipefail

# Replacement run_template_ocean.sh for plain-Spectre run directories.
# Place this file in the run directory and rename/copy it to run_template_ocean.sh.
# It avoids CIW and runs the template-netlisting OCEAN script from a shell-launched
# OCEAN/Virtuoso process.

RUN_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$RUN_DIR"

LOG_DIR="$RUN_DIR/logs"
mkdir -p "$LOG_DIR"
LOG="$LOG_DIR/template_ocean_shell.log"
: > "$LOG"

# Load run metadata if present. Do not fail if older run dirs lack it.
if [ -f "$RUN_DIR/RUNINFO.txt" ]; then
  # shellcheck disable=SC1091
  source "$RUN_DIR/RUNINFO.txt" || true
fi

# Infer repository root if not provided.
if [ -z "${REPO_DIR:-}" ]; then
  REPO_DIR="$(cd "$RUN_DIR/../.." 2>/dev/null && pwd || true)"
fi

# Candidate OCEAN scripts, in decreasing preference.
OCN=""
for cand in \
  "$RUN_DIR/ocn/template_netlist.ocn" \
  "$RUN_DIR/ocn/template_netlist.OCN" \
  "$RUN_DIR/ocn/make_spectre_template_v1.ocn" \
  "$RUN_DIR/ocn/make_spectre_template_v1.OCN" \
  "$RUN_DIR/ocn/"*.ocn \
  "$RUN_DIR/ocn/"*.OCN
  do
    if [ -f "$cand" ]; then
      OCN="$cand"
      break
    fi
  done

if [ -z "$OCN" ]; then
  echo "ERROR: no template OCEAN script found in $RUN_DIR/ocn" | tee -a "$LOG"
  ls -la "$RUN_DIR/ocn" 2>&1 | tee -a "$LOG" || true
  exit 1
fi

# Environment variables consumed by the template OCEAN script variants used in this pipeline.
export RUN_DIR
export CAD_RUN_DIR="$RUN_DIR"
export CAD_TEMPLATE_DIR="$RUN_DIR/template_ocean_result"
export CAD_PROJECT_DIR="$RUN_DIR/template_project"
export CAD_BATCH_EXIT=1
[ -n "${REPO_DIR:-}" ] && export REPO_DIR CAD_REPO_DIR="$REPO_DIR"
mkdir -p "$CAD_TEMPLATE_DIR" "$CAD_PROJECT_DIR"

# Common BICS/Cadence setup hooks. These are optional because many terminals have
# the environment preloaded already. Keep non-fatal.
for setup in \
  /projects/bics/setup.sh \
  /projects/bics/setup_centos_only.sh \
  /projects/bics/setup_centOS_only.sh \
  /etc/profile.d/cadence.sh
  do
    if [ -f "$setup" ]; then
      # shellcheck disable=SC1090
      source "$setup" >> "$LOG" 2>&1 || true
    fi
  done

# Prefer ocean if it exists; otherwise use the Virtuoso OCEAN mode that worked in
# earlier process listings: virtuoso -ocean -nographE -restore <ocn>.
OCEAN_BIN="$(command -v ocean 2>/dev/null || true)"
VIRTUOSO_BIN="$(command -v virtuoso 2>/dev/null || true)"

if [ -z "$VIRTUOSO_BIN" ]; then
  for cand in \
    /projects/bics/cadence/installs/IC231/tools.lnx86/dfII/bin/64bit/virtuoso \
    /projects/bics/cadence/installs/IC231/tools.lnx86/dfII/bin/virtuoso \
    /projects/bics/cadence/installs/IC231/tools/bin/virtuoso
    do
      if [ -x "$cand" ]; then
        VIRTUOSO_BIN="$cand"
        break
      fi
    done
fi

{
  echo "=== template shell OCEAN run ==="
  echo "date=$(date -Is)"
  echo "RUN_DIR=$RUN_DIR"
  echo "REPO_DIR=${REPO_DIR:-unset}"
  echo "OCN=$OCN"
  echo "CAD_TEMPLATE_DIR=$CAD_TEMPLATE_DIR"
  echo "CAD_PROJECT_DIR=$CAD_PROJECT_DIR"
  echo "OCEAN_BIN=${OCEAN_BIN:-not found}"
  echo "VIRTUOSO_BIN=${VIRTUOSO_BIN:-not found}"
  echo
} | tee -a "$LOG"

rc=0
if [ -n "$OCEAN_BIN" ]; then
  echo "Running: $OCEAN_BIN -nograph -restore $OCN" | tee -a "$LOG"
  "$OCEAN_BIN" -nograph -restore "$OCN" >> "$LOG" 2>&1 || rc=$?
elif [ -n "$VIRTUOSO_BIN" ]; then
  echo "Running: $VIRTUOSO_BIN -ocean -nographE -restore $OCN" | tee -a "$LOG"
  "$VIRTUOSO_BIN" -ocean -nographE -restore "$OCN" >> "$LOG" 2>&1 || rc=$?
else
  echo "ERROR: neither ocean nor virtuoso is available in this shell." | tee -a "$LOG"
  echo "Load the BICS Cadence environment in this terminal, then rerun ./run_template_ocean.sh" | tee -a "$LOG"
  exit 2
fi

if [ "$rc" -ne 0 ]; then
  echo "ERROR: template OCEAN run failed with rc=$rc" | tee -a "$LOG"
  echo "Last 80 log lines:" | tee -a "$LOG"
  tail -80 "$LOG"
  exit "$rc"
fi

echo "=== template OCEAN run finished successfully ===" | tee -a "$LOG"
echo "Potential generated artifacts:" | tee -a "$LOG"
find "$RUN_DIR" /home/s5117909/simulation -maxdepth 6 \
  \( -name input.scs -o -name artSimEnvLog -o -name ade_e.scs \) \
  -print 2>/dev/null | head -80 | tee -a "$LOG" || true

echo
echo "Next: ./import_template.sh"
