#!/usr/bin/env bash
set -u -o pipefail
JOB_INDEX="${1:?usage: run_spectre_worker.sh JOB_INDEX}"
RUN_DIR="$(cd "$(dirname "$0")" && pwd -P)"
# shellcheck disable=SC1091
source "$RUN_DIR/RUNINFO.txt"
# shellcheck disable=SC1091
source "$RUN_DIR/setup_spectre_env.sh"
TEMPLATE="$RUN_DIR/netlist_template/raw"
LOG="$RUN_DIR/logs/spectre_worker_${JOB_INDEX}.log"
ASSIGNED_TSV="$RUN_DIR/worker_state/job_${JOB_INDEX}_cases.tsv"
mkdir -p "$RUN_DIR/logs" "$RUN_DIR/worker_state"
{ echo "worker=$JOB_INDEX start=$(date -Is)"; echo "SPECTRE_CMD=${SPECTRE_CMD:-unset}"; echo "CADENCE_EXPORT_LAUNCHER=${CADENCE_EXPORT_LAUNCHER:-unset}"; check_spectre_runtime; check_export_runtime || true; } > "$LOG" 2>&1
spectre_runtime_ok || { echo "FAILED: Spectre runtime unresolved" | tee -a "$LOG"; exit 2; }
[[ -f "$TEMPLATE/input.scs" ]] || { echo "FAILED: missing template $TEMPLATE/input.scs" | tee -a "$LOG"; exit 1; }
python3 "$RUN_DIR/select_cases.py" "$RUN_DIR/cases.csv" "$JOB_INDEX" "$NUM_JOBS" > "$ASSIGNED_TSV"
echo "assigned_cases=$(wc -l < "$ASSIGNED_TSV")" | tee -a "$LOG"
while IFS=$'\t' read -r case_id run_name st1_file st2_file case_dir; do
  {
    echo "========== case_id=$case_id run_name=$run_name =========="
    mkdir -p "$case_dir"
    [[ -f "$case_dir/output_signals.txt" ]] && { echo "SKIP existing output_signals.txt"; continue; }
    rm -rf "$case_dir/netlist" "$case_dir/psf"
    cp -a "$TEMPLATE" "$case_dir/netlist"
    python3 - "$case_dir/netlist" "$st1_file" "$st2_file" <<'PY'
import pathlib, sys
root = pathlib.Path(sys.argv[1])
def q(path): return '"' + path.replace('\\','\\\\').replace('"','\\"') + '"'
st1, st2 = q(sys.argv[2]), q(sys.argv[3])
changed=0
for p in root.rglob('*'):
    if not p.is_file(): continue
    try: s=p.read_text(errors='ignore')
    except Exception: continue
    ns=s.replace('__ST1_PWL__', st1).replace('__ST2_PWL__', st2)
    if ns != s: p.write_text(ns); changed += 1
print(f'patched_files={changed}')
PY
    ( cd "$case_dir/netlist" || exit 1; "$SPECTRE_CMD" input.scs +escchars +log "$case_dir/spectre.out" -format psfxl -raw "$case_dir/psf" )
    rc=$?
    [[ "$rc" -eq 0 ]] || { echo "FAILED case_id=$case_id spectre_rc=$rc"; echo "case_id=$case_id" >> "$RUN_DIR/worker_state/job_${JOB_INDEX}_failed.txt"; continue; }
    "$RUN_DIR/run_export_case.sh" "$case_dir"
    rc=$?
    [[ "$rc" -eq 0 && -f "$case_dir/output_signals.txt" ]] || { echo "FAILED case_id=$case_id export_rc=$rc"; echo "case_id=$case_id" >> "$RUN_DIR/worker_state/job_${JOB_INDEX}_failed.txt"; continue; }
    echo "DONE case_id=$case_id"
    echo "$case_id" >> "$RUN_DIR/worker_state/job_${JOB_INDEX}_done.txt"
  } >> "$LOG" 2>&1
done < "$ASSIGNED_TSV"
echo "worker=$JOB_INDEX end=$(date -Is)" >> "$LOG"
