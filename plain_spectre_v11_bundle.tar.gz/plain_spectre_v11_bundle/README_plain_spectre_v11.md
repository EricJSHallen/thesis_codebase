# Plain Spectre Pipeline v11

Fixes the v10 failure where Spectre reported `Unexpected operator "/"` and `Badly formed parameters statement` in `input.scs`.

Cause: workers replaced bare placeholders with unquoted absolute PWL paths. v11 inserts quoted Spectre string values.

## Install from repo root

```bash
tar -xzf plain_spectre_v11_bundle.tar.gz
mkdir -p processing/sim_run_code/plain_spectre_helpers_v11
cp plain_spectre_v11_bundle/setup_spectre_env.sh processing/sim_run_code/plain_spectre_helpers_v11/setup_spectre_env.sh
cp plain_spectre_v11_bundle/refresh_spectre_runtime.sh processing/sim_run_code/plain_spectre_helpers_v11/refresh_spectre_runtime.sh
cp plain_spectre_v11_bundle/run_spectre_worker.sh processing/sim_run_code/plain_spectre_helpers_v11/run_spectre_worker.sh
cp plain_spectre_v11_bundle/run_all_workers.sh processing/sim_run_code/plain_spectre_helpers_v11/run_all_workers.sh
cp plain_spectre_v11_bundle/run_export_case.sh processing/sim_run_code/plain_spectre_helpers_v11/run_export_case.sh
cp plain_spectre_v11_bundle/export_psf_to_txt.ocn processing/sim_run_code/plain_spectre_helpers_v11/export_psf_to_txt.ocn
cp plain_spectre_v11_bundle/spectre_sweep_plain_v11.sh processing/sim_run_code/spectre_sweep_plain_v11.sh
chmod +x processing/sim_run_code/spectre_sweep_plain_v11.sh processing/sim_run_code/plain_spectre_helpers_v11/*.sh
```

## Run

```bash
NUM_JOBS=4 RUN_LABEL=2channel_1syn_plain ./processing/sim_run_code/spectre_sweep_plain_v11.sh prep
cd thesis_database/<new_run_id>
./import_template.sh
grep -R "__ST1_PWL__\|__ST2_PWL__" netlist_template/raw | head
./refresh_spectre_runtime.sh
source ./setup_spectre_env.sh && check_spectre_runtime
./run_all_workers.sh
./monitoring_commands.sh progress
```

Do not run workers if `./import_template.sh` or `check_spectre_runtime` fails.
